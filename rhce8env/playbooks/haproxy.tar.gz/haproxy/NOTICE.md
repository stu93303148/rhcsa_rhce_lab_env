Copyright 2016 ansiblebit

This role used ansiblebit's primogen role as a starting point.
It can be obtained at [github.com/ansiblebit/primogen](https://github.com/ansiblebit/primogen) and
it's licensed under the following [BSD License](https://github.com/ansiblebit/primogen/blob/master/LICENSE).
